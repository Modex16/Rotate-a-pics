﻿namespace System.Windows
{
    internal class Visibility
    {
    }
}